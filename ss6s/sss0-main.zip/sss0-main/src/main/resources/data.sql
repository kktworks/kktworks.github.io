INSERT INTO items(name, price, stock_quantity) 
VALUES
('Java入門', 2480,8),
('Servlet入門', 2980,4),
('Spring Boot入門', 3280,2);
