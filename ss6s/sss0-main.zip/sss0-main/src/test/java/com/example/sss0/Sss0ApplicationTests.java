package com.example.sss0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sss0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
