package com.example.todolist.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "groups")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = { "accountList" })
public class Groups {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    // こちらを被所有者側にする
    @ManyToMany(mappedBy = "groupsList")
    @OrderBy("id asc")
    private List<Account> accountList = new ArrayList<>();

    public Groups(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Groups(Integer id) {
        this.id = id;
    }
}
