\encoding UTF8;
DROP TABLE IF EXISTS groups;
CREATE TABLE groups
(
  id      SERIAL PRIMARY KEY,
  name    TEXT  NOT NULL  
);
SELECT SETVAL('groups_id_seq', 100, false);
INSERT INTO groups(id, name) VALUES(0, '');
INSERT INTO groups(name) VALUES('設計部');
INSERT INTO groups(name) VALUES('経理部');
INSERT INTO groups(name) VALUES('BBQサークル');


DROP TABLE IF EXISTS groups_account;
CREATE TABLE groups_account
(
  id            SERIAL PRIMARY KEY,
  groups_id     INTEGER  NOT NULL,
  account_id    INTEGER  NOT NULL,
  UNIQUE(groups_id, account_id)
  
);

INSERT INTO groups_account(groups_id, account_id) VALUES (100,1);
INSERT INTO groups_account(groups_id, account_id) VALUES (100,3);
INSERT INTO groups_account(groups_id, account_id) VALUES (101,2);
INSERT INTO groups_account(groups_id, account_id) VALUES (102,1);
INSERT INTO groups_account(groups_id, account_id) VALUES (102,2);
INSERT INTO groups_account(groups_id, account_id) VALUES (102,3);
