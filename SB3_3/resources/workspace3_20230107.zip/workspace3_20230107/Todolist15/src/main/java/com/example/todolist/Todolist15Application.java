package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist15Application {

	public static void main(String[] args) {
		SpringApplication.run(Todolist15Application.class, args);
	}

}
