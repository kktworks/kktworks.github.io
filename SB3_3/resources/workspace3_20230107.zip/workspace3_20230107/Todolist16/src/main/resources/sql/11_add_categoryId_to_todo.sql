ALTER TABLE todo ADD COLUMN category_id INTEGER;
UPDATE todo SET category_id=1;
ALTER TABLE todo ALTER COLUMN category_id SET NOT NULL;