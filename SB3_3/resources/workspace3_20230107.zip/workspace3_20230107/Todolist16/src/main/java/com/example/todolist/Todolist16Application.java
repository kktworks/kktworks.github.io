package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist16Application {

	public static void main(String[] args) {
		SpringApplication.run(Todolist16Application.class, args);
	}

}
