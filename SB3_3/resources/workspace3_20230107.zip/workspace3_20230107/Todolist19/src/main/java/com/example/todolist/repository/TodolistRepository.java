package com.example.todolist.repository;

import java.sql.Date;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.todolist.entity.Todolist;

@Repository
public interface TodolistRepository extends JpaRepository<Todolist, Integer> {
  // 検索条件に期限を含む
  Page<Todolist>
    findByOwnerIdAndTitleLikeAndImportanceInAndUrgencyInAndDeadlineBetweenAndDoneIn(
      Integer ownerId, String title,
      List<Integer> importance, List<Integer> urgency, Date from ,Date to, List<String> done, 
      Pageable pageable);

  // 検索条件に期限を含まない
  Page<Todolist> findByOwnerIdAndTitleLikeAndImportanceInAndUrgencyInAndDoneIn(
    Integer ownerId, String title,
    List<Integer> importance, List<Integer> urgency, List<String> done, 
    Pageable pageable);
}
