ALTER TABLE todo ADD COLUMN completed_tasks INTEGER;
UPDATE todo SET completed_tasks = 0;
WITH with_completed AS (
  SELECT todo_id, COUNT(done='Y' OR NULL) AS completed
    FROM task GROUP BY todo_id
)
UPDATE todo td
   SET completed_tasks = tmp.completed
  FROM with_completed tmp
 WHERE td.id = tmp.todo_id;
ALTER TABLE todo ALTER COLUMN completed_tasks SET NOT NULL;