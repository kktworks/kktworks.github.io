ALTER TABLE task ADD COLUMN assigned_to  INTEGER;
ALTER TABLE task ADD COLUMN progress INTEGER;
UPDATE task SET assigned_to=0, progress = 0;
ALTER TABLE task ALTER COLUMN progress SET NOT NULL;
