package com.example.todolist.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryKey implements Serializable{
    private static final long serialVersionUID = 1L;

    @Column(name = "code")
    private String code;
    
    @Column(name = "locale")
    private String locale;
}
