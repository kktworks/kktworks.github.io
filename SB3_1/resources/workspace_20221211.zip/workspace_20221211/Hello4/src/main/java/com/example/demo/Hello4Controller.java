package com.example.demo;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello4Controller {
	@PostMapping("/hello4") // ①
	public String sayHello(@RequestParam("name") String name) { // ②
		return "Hello, world! " + "こんにちは " + name + "さん!";
	}
}
