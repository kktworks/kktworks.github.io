package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist2Application {

	public static void main(String[] args) {
		SpringApplication.run(Todolist2Application.class, args);
	}

}
