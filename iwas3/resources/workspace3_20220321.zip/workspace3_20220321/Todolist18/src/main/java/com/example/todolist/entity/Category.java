package com.example.todolist.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "category")
@Data
@ToString(exclude = "todoList")
@NoArgsConstructor
public class Category implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CategoryKey pkey;

	@Column(name = "name")
	private String name;

	@OneToMany(mappedBy = "category")
	@OrderBy("id asc")
	private List<Todo> todoList = new ArrayList<>();

	public Category(String code, String locale, String name) {
		this(code, locale);
		this.name = name;
	}

	public Category(String code, String locale) {
		this.pkey = new CategoryKey(code, locale);
		this.name = "";
	}
}