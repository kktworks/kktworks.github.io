package com.example.todolist.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.todolist.common.OpMsg;
import com.example.todolist.entity.Account;
import com.example.todolist.entity.AttachedFile;
import com.example.todolist.entity.Category;
import com.example.todolist.entity.Groups;
import com.example.todolist.entity.Task;
import com.example.todolist.entity.Todo;
import com.example.todolist.entity.Todolist;
import com.example.todolist.form.TaskData;
import com.example.todolist.form.TodoData;
import com.example.todolist.form.TodoQuery;
import com.example.todolist.repository.AccountRepository;
import com.example.todolist.repository.AttachedFileRepository;
import com.example.todolist.repository.CategoryRepository;
import com.example.todolist.repository.GroupsRepository;
import com.example.todolist.repository.TaskRepository;
import com.example.todolist.repository.TodoRepository;
import com.example.todolist.service.TodoService;
import com.example.todolist.view.TodoExcel;
import com.example.todolist.view.TodoPdf;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class TodoListController {
	private final TodoRepository todoRepository;
	private final TodoService todoService;
	private final HttpSession session;
	private final MessageSource messageSource;
	private final AttachedFileRepository attachedFileRepository;
	private final CategoryRepository categoryRepository;
	private final AccountRepository accountRepository;
	private final GroupsRepository groupsRepository;
	private final TaskRepository taskRepository;

	// ToDo一覧表示
	@GetMapping("/todo")
	public ModelAndView showTodoList(ModelAndView mv,
			@PageableDefault(page = 0, size = 5, sort = "id") Pageable pageable) {
		// sessionから前回の検索条件を取得
		TodoQuery todoQuery = (TodoQuery) session.getAttribute("todoQuery");
		if (todoQuery == null) {
			// なければ初期値を使う
			todoQuery = new TodoQuery();
			session.setAttribute("todoQuery", todoQuery);
		}

		// sessionから前回のpageableを取得
		Pageable prevPageable = (Pageable) session.getAttribute("prevPageable");
		if (prevPageable == null) {
			// なければ@PageableDefaultを使う
			prevPageable = pageable;
			session.setAttribute("prevPageable", prevPageable);
		}

		mv.setViewName("todoList");

		// Todo検索
		Integer accountId = (Integer) session.getAttribute("accountId");
		Page<Todolist> todoPage = todoService.findByCriteria(todoQuery, accountId, prevPageable);
		mv.addObject("todoQuery", todoQuery); // 検索条件
		mv.addObject("todoPage", todoPage); // page情報
		mv.addObject("todoList", todoPage.getContent()); // 検索結果

		// カテゴリ取得
		@SuppressWarnings("unchecked")
		List<Category> categoryList = (List<Category>) session.getAttribute("categoryList");
		if (categoryList == null) {
			String locale = LocaleContextHolder.getLocale().toString();
			categoryList = categoryRepository.findByPkey_localeOrderByPkey_code(locale);
			categoryList.add(0, new Category("", locale, "---------"));
			session.setAttribute("categoryList", categoryList);
		}

		// 所属グループ取得
		@SuppressWarnings("unchecked")
		List<Groups> groupsList = (List<Groups>) session.getAttribute("groupsList");
		if (groupsList == null) {
			Account myAccount = accountRepository.findById(accountId).get();
			groupsList = new ArrayList<>();
			groupsList.addAll(myAccount.getGroupsList());
			session.setAttribute("groupsList", groupsList);
		}

		return mv;
	}

	// ToDo表示
	@GetMapping("/todo/{id}")
	public ModelAndView todoById(@PathVariable(name = "id") int id, ModelAndView mv,
			RedirectAttributes redirectAttributes, Locale locale) {
		// ToDo取得
		Optional<Todo> someTodo = todoRepository.findById(id);
		someTodo.ifPresentOrElse(todo -> {
			// todoは存在する
			Integer accountId = (Integer) session.getAttribute("accountId");
			// 操作者の ToDo か? or Todo と同じグループに所属しているか？
			@SuppressWarnings("unchecked")
			List<Groups> groupsList = (List<Groups>) session.getAttribute("groupsList");
			if (todo.getOwnerId().equals(accountId) || isBelong(groupsList, todo.getGroups())) {
				mv.setViewName("todoForm");
				// 添付ファイル取得
				List<AttachedFile> attachedFiles = attachedFileRepository.findByTodoIdOrderById(id);
				// 表示用データ作成
				mv.addObject("todoData", new TodoData(todo, attachedFiles));

				// 担当者の選択肢
				List<Account> assignedToList = new ArrayList<>();
				assignedToList.add(new Account(0, "---------"));
				if (todo.getGroups().getId() != 0) {
					// グループで共有している Todo なので、そのグループに属している人を担当者の選択肢とする
					Groups groups = groupsRepository.findById(todo.getGroups().getId()).get();
					assignedToList.addAll(groups.getAccountList());
				}
				session.setAttribute("assignedToList", assignedToList);

				session.setAttribute("mode", "update");
			} else {
				// 操作者のものでない
				operationError(mv, redirectAttributes, locale);
			}
		}, () -> {
			// todoが存在しない
			operationError(mv, redirectAttributes, locale);
		});

		return mv;
	}

	// ToDo入力フォーム表示
	@PostMapping("/todo/create/form")
	public ModelAndView createTodo(ModelAndView mv) {
		mv.setViewName("todoForm");
		mv.addObject("todoData", new TodoData());
		session.setAttribute("mode", "create");
		return mv;
	}

	// ToDo追加処理
	@PostMapping("/todo/create/do")
	public String createTodo(@ModelAttribute @Validated TodoData todoData, BindingResult result, Model model,
			RedirectAttributes redirectAttributes, Locale locale) {
		// エラーチェック
		boolean isValid = todoService.isValid(todoData, result, true, locale);
		if (!result.hasErrors() && isValid) {
			// エラーなし -> 追加
			Todo todo = todoData.toEntity(); // ①
			todo.setOwnerId((Integer)session.getAttribute("accountId"));
			//todoRepository.saveAndFlush(todo);
			// ↓
			Todo _todo = todoRepository.saveAndFlush(todo); // ②戻り値取得
			// 追加完了メッセージをセットしてリダイレクト
			String msg = messageSource.getMessage("msg.i.todo_created", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
			//return "redirect:/todo/" + todo.getId();
			// ↓
			return "redirect:/todo/" + _todo.getId(); // ③戻り値から id 取得

		} else {
			// エラーあり -> エラーメッセージをセット
			String msg = messageSource.getMessage("msg.e.input_something_wrong", null, locale);
			model.addAttribute("msg", new OpMsg("E", msg));
			return "todoForm";
		}
	}

	// ToDo 更新処理
	@PostMapping("/todo/update")
	public String updateTodo(@ModelAttribute TodoData todoData, BindingResult result, Model model,
			RedirectAttributes redirectAttributes, Locale locale) {
		// エラーチェック
		boolean isValid = todoService.isValid(todoData, result, false, locale);
		if (result.hasErrors() || !isValid) {
			// エラーあり -> エラーメッセージをセット
			String msg = messageSource.getMessage("msg.e.input_something_wrong", null, locale);
			model.addAttribute("msg", new OpMsg("E", msg));
			return "todoForm";
		}
		Todo todo = todoData.toEntity();
		// 完了タスク数
		if (todoData.getTaskList() != null) {
			int numOfCompletedTasks 
			= (int) todoData.getTaskList().stream().filter(task -> task.getDone().equals("Y"))
					.count();
			todo.setCompletedTasks(numOfCompletedTasks);
		}
		// --------------------------------------------------
		// - 更新前の整合性確認
		// --------------------------------------------------
		// 更新対象 Todo(と Task)を取得
		Optional<Todo> _targetTodo = todoRepository.findById(todoData.getId());
		if (!_targetTodo.isPresent()) {
			// 更新対象 Todo が存在しない -> 削除された
			String msg = messageSource.getMessage("msg.w.todo_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			return "redirect:/todo";
		}
		// Todo の vesrion 確認
		Todo targetTodo = _targetTodo.get();
		if (!targetTodo.getVersion().equals(todo.getVersion())) {
			// version 不一致 -> 更新されている
			String msg = messageSource.getMessage("msg.w.optimistic_locking_failure", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			return "redirect:/todo/" + todo.getId();
		}
		// Task の存在/version 確認
		boolean isTaskOk = true;
		if (todoData.getTaskList() != null) {
			for (TaskData taskData : todoData.getTaskList()) {
				Optional<Task> _task = taskRepository.findById(taskData.getId());
				if (_task.isPresent()) {
					Task task = _task.get();
					// version 不一致
					if (!task.getVersion().equals(taskData.getVersion())) {
						isTaskOk = false;
						break;
					}
				} else {
					// Task が存在しない
					isTaskOk = false;
					break;
				}
			}
			if (!isTaskOk) {
				// 削除 or 更新されている
				String msg = messageSource.getMessage("msg.w.optimistic_locking_failure", null, locale);
				redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
				return "redirect:/todo/" + todo.getId();
			}
		}
	// --------------------------------------------------
	// - 更新処理
	// --------------------------------------------------
	try {
	todo = todoRepository.saveAndFlush(todo);
	// 更新完了メッセージをセットしてリダイレクト
	String msg = messageSource.getMessage("msg.i.todo_updated", null, locale);
	redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
	return "redirect:/todo/" + todo.getId();
	} catch (org.springframework.orm.ObjectOptimisticLockingFailureException e) {
	// task の更新が競合した(=誰かが先に更新 or 削除したとき)
	String msg = messageSource.getMessage(
	"msg.w.optimistic_locking_failure", null, locale);
	redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
	return "redirect:/todo/" + todo.getId();
	}
	}
	// ToDo削除処理
	@PostMapping("/todo/delete")
	public String deleteTodo(@ModelAttribute TodoData todoData, RedirectAttributes redirectAttributes, Locale locale) {
		Integer todoId = todoData.getId();

		// 削除できるのは登録者のみ
		Integer accountId = (Integer) session.getAttribute("accountId");
		if (!todoData.getOwnerId().equals(accountId)) {
			// 削除 NG メッセージをセットしてリダイレクト
			String msg = messageSource.getMessage("msg.e.todo_cannot_delete", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("E", msg));
			return "redirect:/todo/" + todoId;
		}
		// ---------- 追加ここから ↓↓↓ ----------
		// 存在チェック
		Optional<Todo> _targetTodo = todoRepository.findById(todoId);
		if (!_targetTodo.isPresent()) {
			// 更新対象 Todo が存在しない -> 削除された
			String msg = messageSource.getMessage("msg.w.todo_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			return "redirect:/todo";
		}
		// ---------- 追加ここまで ↑↑↑ ----------

		// 添付ファイルを削除
		todoService.deleteAttachedFiles(todoId);

		// attached_fileテーブルから削除
		List<AttachedFile> attachedFiles = attachedFileRepository.findByTodoIdOrderById(todoId);
		attachedFileRepository.deleteAllInBatch(attachedFiles);

		// todoを削除
		todoRepository.deleteById(todoData.getId());

		// 削除完了メッセージをセットしてリダイレクト
		String msg = messageSource.getMessage("msg.i.todo_deleted", null, locale);
		redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
		return "redirect:/todo";
	}

	// ToDo検索処理
	@PostMapping("/todo/query")
	public ModelAndView queryTodo(@ModelAttribute TodoQuery todoQuery, BindingResult result,
			@PageableDefault(page = 0, size = 5, sort = "id") Pageable pageable, ModelAndView mv, Locale locale) {
		mv.setViewName("todoList");

		Page<Todolist> todoPage = null;
		if (todoService.isValid(todoQuery, result, locale)) {
			// エラーがなければ検索
			Integer accountId = (Integer) session.getAttribute("accountId");
			todoPage = todoService.findByCriteria(todoQuery, accountId, pageable);
			// 入力された検索条件をsessionへ保存
			session.setAttribute("todoQuery", todoQuery);

			mv.addObject("todoPage", todoPage);
			mv.addObject("todoList", todoPage.getContent());

			// 該当なかったらメッセージを表示
			if (todoPage.getContent().size() == 0) {
				String msg = messageSource.getMessage("msg.w.todo_not_found", null, locale);
				mv.addObject("msg", new OpMsg("W", msg));
			}

		} else {
			// 検索条件エラーあり -> エラーメッセージをセット
			String msg = messageSource.getMessage("msg.e.input_something_wrong", null, locale);
			mv.addObject("msg", new OpMsg("E", msg));

			mv.addObject("todoPage", null);
			mv.addObject("todoList", null);
		}

		// mv.addObject("todoQuery", todoQuery);
		return mv;
	}

	// ページリンク押下時
	@GetMapping("/todo/query")
	public ModelAndView queryTodo(@PageableDefault(page = 0, size = 5, sort = "id") Pageable pageable,
			ModelAndView mv) {
		// 現在のページ位置を保存
		session.setAttribute("prevPageable", pageable);

		mv.setViewName("todoList");

		// sessionに保存されている条件で検索
		TodoQuery todoQuery = (TodoQuery) session.getAttribute("todoQuery");
		Integer accountId = (Integer) session.getAttribute("accountId");
		Page<Todolist> todoPage = todoService.findByCriteria(todoQuery, accountId, pageable);

		mv.addObject("todoQuery", todoQuery); // 検索条件
		mv.addObject("todoPage", todoPage); // page情報
		mv.addObject("todoList", todoPage.getContent()); // 検索結果

		return mv;
	}

	// Task追加処理
	@PostMapping("/task/create")
	public String createTask(@ModelAttribute TodoData todoData, BindingResult result, Model model,
			RedirectAttributes redirectAttributes, Locale locale) {
		// エラーチェック
		boolean isValid = todoService.isValid(todoData.getNewTask(), result, locale);
		if (isValid) {
			// エラーなし
			Todo todo = todoData.toEntity();
			Task task = todoData.toTaskEntity();
			task.setTodo(todo);
			try {
				// この中で Task を追加し、 Todo の completed_tasks を再計算する
				todoService.createTaskAndRecalcCompletedTasks(task, todo.getId());

				// 追加完了メッセージをセットしてリダイレク ト
				String msg = messageSource.getMessage("msg.i.task_created", null, locale);
				redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
				return "redirect:/todo/" + todo.getId();

			} catch (Exception e) {
				e.printStackTrace();
				// Rollback されている
				return "redirect:/error";
			}

		} else {
			// エラーあり -> エラーメッセージをセット
			String msg = messageSource.getMessage("msg.e.input_something_wrong", null, locale);
			model.addAttribute("msg", new OpMsg("E", msg));
			return "todoForm";
		}
	}

	// Task 削除処理
	@GetMapping("/task/delete")
	public ModelAndView deleteTask(@RequestParam(name = "task_id") int taskId,
			@RequestParam(name = "todo_id") int todoId, ModelAndView mv, RedirectAttributes redirectAttributes,
			Locale locale) {
		// ToDo 取得 -> なければ削除済
		Optional<Todo> _todo = todoRepository.findById(todoId);
		if (!_todo.isPresent()) {
			String msg = messageSource.getMessage("msg.w.todo_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			mv.setViewName("redirect:/todo");
			return mv;
		}
		// 操作者の ToDo か? or Todo と同じグループに所属しているか？
		Todo todo = _todo.get();
		Integer accountId = (Integer) session.getAttribute("accountId");
		@SuppressWarnings("unchecked")
		List<Groups> groupsList = (List<Groups>) session.getAttribute("groupsList");
		if (!todo.getOwnerId().equals(accountId) && !isBelong(groupsList, todo.getGroups())) {
			operationError(mv, redirectAttributes, locale);
			return mv;
		}
		// --------------------------------------------------
		// - 削除
		// --------------------------------------------------
		Optional<Task> _task = taskRepository.findById(taskId);
		if (_task.isPresent()) {
			try {
				// この中で Task を削除し、 Todo の completed_tasks を再計算する
				todoService.deleteTaskAndRecalcCompletedTasks(taskId, todo);
				// 削除完了メッセージをセットしてリダイレクト
				String msg = messageSource.getMessage("msg.i.task_deleted", null, locale);
				redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
				mv.setViewName("redirect:/todo/" + todoId);
			} catch (Exception e) {
				e.printStackTrace();
				// Rollback されている
				operationError(mv, redirectAttributes, locale);
			}
		} else {
			// Task が存在しない -> Task 削除済
			String msg = messageSource.getMessage("msg.w.task_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			mv.setViewName("redirect:/todo/" + todoId);
		}
		return mv;
	}

	// 添付ファイルをアップロードする
	@PostMapping("/todo/af/upload")
	public String uploadAttachedFile(@RequestParam("todo_id") int todoId, @RequestParam("note") String note,
			@RequestParam("file_contents") MultipartFile fileContents, RedirectAttributes redirectAttributes,
			Locale locale) {
		// ---------- 追加ここから↓↓↓ ----------
		// ToDo 取得
		Optional<Todo> someTodo = todoRepository.findById(todoId);
		if (!someTodo.isPresent()) {
			// Todo が存在しない -> Todo 削除済
			String msg = messageSource.getMessage("msg.w.todo_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			return "redirect:/todo";
		}
		// ---------- 追加ここまで↑↑↑ ----------
		
		// ファイルが空？
		if (fileContents.isEmpty()) {
			// ファイルemptyのメッセージをセット
			String msg = messageSource.getMessage("msg.w.attachedfile_empty", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));

		} else {
			// ファイルを保存する
			todoService.saveAttachedFile(todoId, note, fileContents);
			// Upload完了メッセージをセット
			String msg = messageSource.getMessage("msg.i.attachedfile_uploaded", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
		}
		// 再表示
		return "redirect:/todo/" + todoId;
	}

	// 添付ファイルを削除する
	@GetMapping("/todo/af/delete")
	public ModelAndView deleteAttachedFile(@RequestParam(name = "af_id") int afId,
			@RequestParam(name = "todo_id") int todoId, ModelAndView mv, RedirectAttributes redirectAttributes,
			Locale locale) {
		// ToDo取得
		Optional<Todo> someTodo = todoRepository.findById(todoId);
		someTodo.ifPresentOrElse(todo -> {
			// todoは存在する
			Integer accountId = (Integer) session.getAttribute("accountId");
			// 操作者のToDoか?
			if (todo.getOwnerId().equals(accountId)) {
				// 添付ファイルを削除
				todoService.deleteAttachedFile(afId);
				// attached_fileテーブルから削除
				attachedFileRepository.deleteById(afId);

				// 削除完了メッセージをセットしてリダイレクト
				String msg = messageSource.getMessage("msg.i.attachedfile_deleted", null, locale);
				redirectAttributes.addFlashAttribute("msg", new OpMsg("I", msg));
				mv.setViewName("redirect:/todo/" + todoId);

			} else {
				// 操作者のものでない
				operationError(mv, redirectAttributes, locale);

			}
		}, () -> {
			// todo が存在しない
			// operationError(mv, redirectAttributes, locale);
			// ↓
			// Todo が存在しない -> Todo 削除済
			String msg = messageSource.getMessage("msg.w.todo_already_deleted", null, locale);
			redirectAttributes.addFlashAttribute("msg", new OpMsg("W", msg));
			mv.setViewName("redirect:/todo");


		});

		return mv;
	}

	// PDF生成処理
	@GetMapping("/todo/pdf")
	public TodoPdf writeTodoPdf(TodoPdf pdf) {
		Integer accountId = (Integer) session.getAttribute("accountId");
		List<Todo> todoList = todoRepository.findByOwnerIdOrderById(accountId);
		pdf.addStaticAttribute("todoList", todoList);
		return pdf;
	}

	// Excel生成処理
	@GetMapping("/todo/excel")
	public TodoExcel writeTodoExcel(TodoExcel excel) {
		Integer accountId = (Integer) session.getAttribute("accountId");
		List<Todo> todoList = todoRepository.findByOwnerIdOrderById(accountId);
		excel.addStaticAttribute("todoList", todoList);
		excel.addStaticAttribute("fileName", "todoExcel.xlsx");

		return excel;
	}

	// ToDo一覧へ戻る
	@PostMapping("/todo/cancel")
	public String cancel() {
		return "redirect:/todo";
	}

	// 所属するグループか？
	private boolean isBelong(List<Groups> groupsList, Groups groups) {
		return groupsList.stream().anyMatch(g -> g.getId().equals(groups.getId()));
	}

	// errorへリダイレクトする準備
	private void operationError(ModelAndView mv, RedirectAttributes redirectAttributes, Locale locale) {
		session.invalidate();
		String msg = messageSource.getMessage("msg.e.operation_error", null, locale);
		redirectAttributes.addFlashAttribute("msg", new OpMsg("E", msg));
		mv.setViewName("redirect:/error");
	}
}
