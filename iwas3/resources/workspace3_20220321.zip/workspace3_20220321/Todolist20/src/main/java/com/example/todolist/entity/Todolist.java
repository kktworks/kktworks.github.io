package com.example.todolist.entity;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "v_todolist")
@Data
public class Todolist {
	@Id
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "owner_id")
	private Integer ownerId;
	
	@Column(name = "cname")
	private String cname;
	
	@Column(name = "gname")
	private String gname;
	
	@Column(name = "title")
	private String title;
	
	@Column(name = "importance")
	private Integer importance;
	
	@Column(name = "urgency")
	private Integer urgency;
	
	@Column(name = "task")
	private Integer numOfTasks;
	
	@Column(name = "deadline")
	private Date deadline;
	
	@Column(name = "done")
	private String done;
	
	@Column(name = "completed_tasks") // 追加
	private Integer completedTasks; // 追加

}