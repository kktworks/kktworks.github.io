\encoding UTF8;
DROP TABLE IF EXISTS category;
CREATE TABLE category
(
    id        SERIAL PRIMARY KEY,
    name      TEXT
);
INSERT INTO category(name) VALUES('仕事');
INSERT INTO category(name) VALUES('勉強');
INSERT INTO category(name) VALUES('レジャー');
