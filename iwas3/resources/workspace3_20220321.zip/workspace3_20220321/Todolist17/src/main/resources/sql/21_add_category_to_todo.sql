ALTER TABLE todo DROP COLUMN category_id;

ALTER TABLE todo ADD COLUMN category_code TEXT;
ALTER TABLE todo ADD COLUMN category_locale TEXT;

UPDATE todo SET category_code='10';
UPDATE todo SET category_locale='ja';

ALTER TABLE todo ALTER COLUMN category_code SET NOT NULL;
ALTER TABLE todo ALTER COLUMN category_locale SET NOT NULL;