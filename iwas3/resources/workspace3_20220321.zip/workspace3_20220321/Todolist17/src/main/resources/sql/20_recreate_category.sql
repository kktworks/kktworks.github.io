\encoding UTF8;
DROP TABLE IF EXISTS category;
CREATE TABLE category
(
    code      TEXT,
    locale    TEXT,
    name      TEXT,
    PRIMARY KEY(code, locale)
);
INSERT INTO category(code, locale, name) VALUES('10', 'ja', '仕事');
INSERT INTO category(code, locale, name) VALUES('20', 'ja', '勉強');
INSERT INTO category(code, locale, name) VALUES('30', 'ja', 'レジャー');
INSERT INTO category(code, locale, name) VALUES('10', 'en_US', 'Job');
INSERT INTO category(code, locale, name) VALUES('20', 'en_US', 'Study');
INSERT INTO category(code, locale, name) VALUES('30', 'en_US', 'Leisure');
