package com.example.todolist.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable // ①
@Data // ②-b
@NoArgsConstructor // ②-c
@AllArgsConstructor
public class CategoryKey implements Serializable { // ②-a
	private static final long serialVersionUID = 1L; // ②-a
	
	@Column(name = "code") // ③
	private String code;
	
	@Column(name = "locale")
	private String locale;
}