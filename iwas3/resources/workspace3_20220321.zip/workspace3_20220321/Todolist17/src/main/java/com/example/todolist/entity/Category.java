package com.example.todolist.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "category")
@Data
@ToString(exclude = "todoList")
@NoArgsConstructor
public class Category implements Serializable { // ①
	private static final long serialVersionUID = 1L;

	// @Id
	// @GeneratedValue(strategy = GenerationType.IDENTITY)
	// @Column(name = "id")
	// private Integer id;
	// ↓
	@EmbeddedId // ②
	private CategoryKey pkey; // ③

	@Column(name = "name")
	private String name;

	@OneToMany(mappedBy = "category")
	@OrderBy("id asc")
	private List<Todo> todoList = new ArrayList<>();

	// public Category(Integer id) {
	// this.id = id;
	// }
	// ↓
	public Category(String code, String locale, String name) { // ④
		this(code, locale);
		this.name = name;
	}

	// public Category(Integer id, String name) {
	// this.id = id;
	// this.name = name;
	// }
	// ↓
	public Category(String code, String locale) { // ④
		this.pkey = new CategoryKey(code, locale);
		this.name = "";
	}
}