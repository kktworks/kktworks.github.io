package com.example.todolist.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "account")
@Data
@NoArgsConstructor
@ToString(exclude = { "password", "groupsList" })
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "login_id")
    private String loginId;

    @Column(name = "name")
    private String name;

    @Column(name = "password")
    private String password;

    // こちらを所有者側にする
    @ManyToMany
    @JoinTable(name = "groups_account",
			    joinColumns = @JoinColumn(name = "account_id"),
			    inverseJoinColumns = @JoinColumn(name = "groups_id"))
    @OrderBy("id asc")
    private List<Groups> groupsList = new ArrayList<>();
    
    public Account(Integer id, String loginId, String name, String password) {
	    this.id = id;
	    this.loginId = loginId;
	    this.name = name;
	    this.password = password;
    }
    public Account(Integer id) {
    	this.id = id;
    }
}
