package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist7xApplication {

	public static void main(String[] args) {
		SpringApplication.run(Todolist7xApplication.class, args);
	}

}
