package com.example.todolist.config;

import java.io.IOException;

import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Component
public class LoginCheckFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, 
                          ServletResponse response, 
                          FilterChain chain)
            throws IOException, ServletException {

        // HttpServletRequest/Response は ServletRequest/Response のサブクラス
        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse res = (HttpServletResponse)response;

        String uri = req.getRequestURI();
        if (uri.startsWith("/todo") || uri.startsWith("/task")) {
            // sessionが存在するか？
            HttpSession session = req.getSession(false);
            if (session == null) {
                // session無し -> Login画面へリダイレクト
                res.sendRedirect("/login");

            } else {
                // sessionにaccountIdが存在するか(=loginしたか?)
                Integer accountId = (Integer)session.getAttribute("accountId");
                if (accountId == null) {
                    // accountId無し -> Loginしていない -> Login画面へリダイレクト
                    res.sendRedirect("/login");

                } else {
                    //  Loginしている -> コントローラーへリクエストを渡す
                    chain.doFilter(request, response);
                }
            }

        } else {
            // check対象外 -> コントローラーへリクエストを渡す
            chain.doFilter(request, response);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}

