package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist13Application {

	public static void main(String[] args) {
		SpringApplication.run(Todolist13Application.class, args);
	}

}
