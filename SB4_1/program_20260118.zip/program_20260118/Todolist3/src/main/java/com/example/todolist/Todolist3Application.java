package com.example.todolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todolist3Application {

	public static void main(String[] args) {
		SpringApplication.run(Todolist3Application.class, args);
	}

}
