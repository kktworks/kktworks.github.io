CREATE TABLE todo
(
  id           SERIAL PRIMARY KEY,
  title        TEXT,     
  importance   INTEGER,  
  urgency      INTEGER,
  deadline     DATE,
  done         TEXT
);

INSERT INTO todo(title, importance, urgency, deadline, done) 
VALUES('todo-1', 0, 0, '2020-10-01', 'N');
INSERT INTO todo(title, importance, urgency, deadline, done) 
VALUES('todo-2', 0, 1, '2020-10-02', 'Y');
INSERT INTO todo(title, importance, urgency, deadline, done) 
VALUES('todo-3', 1, 0, '2020-10-03', 'N');
INSERT INTO todo(title, importance, urgency, deadline, done) 
VALUES('todo-4', 1, 1, '2020-10-04', 'Y');
