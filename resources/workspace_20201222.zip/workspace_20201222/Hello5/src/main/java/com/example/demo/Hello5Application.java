package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hello5Application {

	public static void main(String[] args) {
		SpringApplication.run(Hello5Application.class, args);
	}

}
